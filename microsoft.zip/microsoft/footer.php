<footer class='footer-area section-gap'>
	<div class='container'>
		<div class='row'>
			<div class='col-lg-4 col-md-6 single-footer-widget'>
				<h4>Os nossos serviços</h4>
				<ul>
					<li><a href='#'>Workshops</a></li>
					<li><a href='#'>Palestras</a></li>
					<li><a href='#'>Aulas Digitais</a></li>
					<li><a href='#'>Ajuda em Tempo Real</a></li>
				</ul>
			</div>
			<div class='col-lg-4 col-md-6 single-footer-widget'>
				<h4>Sobre</h4>
				<ul>
					<li><a href='index.php#missao'>A nossa missão</a></li>
					<li><a href='index.php#equipa'>A Equipa</a></li>
					<li><a href='contact.php'>Contacte-nos</a></li>
				</ul>
			</div>
			<!--<div class='col-lg-2 col-md-6 single-footer-widget'>
				<h4>Quick Links</h4>
				<ul>
					<li><a href='#'>Jobs</a></li>
					<li><a href='#'>Brand Assets</a></li>
					<li><a href='#'>Investor Relations</a></li>
					<li><a href='#'>Terms of Service</a></li>
				</ul>
			</div>
			<div class='col-lg-2 col-md-6 single-footer-widget'>
				<h4>Features</h4>
				<ul>
					<li><a href='#'>Jobs</a></li>
					<li><a href='#'>Brand Assets</a></li>
					<li><a href='#'>Investor Relations</a></li>
					<li><a href='#'>Terms of Service</a></li>
				</ul>
			</div>
			<div class='col-lg-2 col-md-6 single-footer-widget'>
				<h4>Resources</h4>
				<ul>
					<li><a href='#'>Guides</a></li>
					<li><a href='#'>Research</a></li>
					<li><a href='#'>Experts</a></li>
					<li><a href='#'>Agencies</a></li>
				</ul>
			</div>-->
			<div class='col-lg-4 col-md-6 single-footer-widget'>
				<a href="http://www.epb.pt" target="_blank"><img src="img/logo_EPB.png" title="Escola Profissional de Braga" style="height: 60px; margin-top: 20%;"/></a>
				<!--<h4>Newsletter</h4>
				<p>Recebe as últimas novidades do clube.</p>
				<div class='form-wrap' id='mc_embed_signup'>
					<form target='_blank' action='https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01'
					 method='get' class='form-inline'>
						<input class='form-control' name='EMAIL' placeholder='Introduza o seu email' onfocus='this.placeholder = ''' onblur='this.placeholder = 'Introduza o seu email ''
						 required='' type='email'>
						<button class='click-btn btn btn-default'><span class='lnr lnr-arrow-right'></span></button>
						<div style='position: absolute; left: -5000px;'>
							<input name='b_36c4fd991d266f23781ded980_aefe40901a' tabindex='-1' value='' type='text'>
						</div>

						<div class='info'></div>
					</form>
				</div>-->
			</div>
		</div>
		<div class='footer-bottom row align-items-center'>
			<p class='footer-text m-0 col-lg-8 col-md-12'><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
				Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with 
				<i class='fa fa-heart-o' aria-hidden='true'></i> by <a href='https://colorlib.com' target='_blank'>Colorlib</a>
			<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
			<!--<div class='col-lg-4 col-md-12'>
				<a href="http://www.epb.pt" target="_blank"><img src="img/logo_EPB.png" title="Escola Profissional de Braga" style="height: 60px;"/></a>
			</div>-->
		</div>
	</div>
</footer>

<!-- ####################### Start Scroll to Top Area ####################### -->
	<div id="back-top" style="display: none;">
		<a title="Topo" href="#"></a>
	</div>
	<!-- ####################### End Scroll to Top Area ####################### -->
