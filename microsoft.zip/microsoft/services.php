<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
		<?php  require_once "links.php"; ?>
	<!-- Site Title -->
	<title>Serviços</title>

	 
</head>

<body>

	<?php  require_once "menu.php"; ?>


	<!-- Start Banner Area -->
	<section class="banner-area relative">
		<div class="container">
			<div class="row d-flex align-items-center justify-content-center">
				<div class="about-content col-lg-12">
					<h1 class="text-white">
						Os nossos serviços
					</h1>
					<div class="link-nav">
						<span class="box">
							<a href="index.php">Início</a>
							<i class="lnr lnr-arrow-right"></i>
							<a href="about.php">Serviços</a>
						</span>
					</div>
				</div>
			</div>
		</div>
		<div class="rocket-img go-bottom">
			<img src="img/rocket.png" alt="" style="margin-bottom:-8px;">
		</div>
	</section>
	<!-- End Banner Area -->


	<!-- Start Services Area -->
	<section class="feature-area">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-8">
					<div class="section-title text-center">
						<h1>Serviços</h1>
					</div>
				</div>
			</div>
			<div class="feature-inner row">
				<div class="col-md-6">
					<div class="feature-item">						
						<img src="img/icons/workshop.png" class="icons_servicos"/> 
						<h4>Workshops</h4>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".1s">
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="feature-item">
						<img src="img/icons/palestras.png" class="icons_servicos"/> 
						<h4>Palestras</h4>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".3s">
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="feature-item">
						<img src="img/icons/aulasdigitais.png" class="icons_servicos"/> 
						<h4>Aulas Digitais</h4>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="feature-item">
						<img src="img/icons/help.png" class="icons_servicos"/> 
						<h4>Ajuda Em Tempo Real</h4>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Services Area -->


	<?php  require_once "footer.php"; ?>


 
</body>

</html>